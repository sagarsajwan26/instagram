I assert that this patch is my own work, and to [simplify the licensing of the BFG Repo-Cleaner](https://github.com/rtyley/bfg-repo-cleaner/blob/master/CONTRIBUTING.md#pull-requests):

_(choose 1 of these 2 options)_

- [ ] I assign the copyright on this contribution to Roberto Tyley
- [ ] I disclaim copyright and thus place this contribution in the public domain

